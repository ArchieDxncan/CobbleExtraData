package com.cobblemon.fabric.example;

import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_332;
import net.minecraft.class_437;
import net.minecraft.nbt.*;
import com.cobblemon.mod.common.pokemon.Pokemon;
import com.mojang.blaze3d.systems.RenderSystem;
import org.lwjgl.opengl.GL11;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.awt.Dimension;
import java.util.List;

public class PokemonInfoScreen extends class_437 {
    private final Pokemon pokemon;
    private class_2960 pokemonSprite;
    private class_2960 originMark;
    public static final Logger LOGGER = LoggerFactory.getLogger("CobbleExtraData");

    protected PokemonInfoScreen(Pokemon pokemon) {
        super(class_2561.method_43470("Pokémon Info"));
        this.pokemon = pokemon;
        String originMarkSprite = pokemon.getPersistentData().method_10545("OriginGame")
                ? pokemon.getPersistentData().method_10558("OriginGame").toLowerCase()
                : "cobblemon";

        // Determine the sprite path based on whether the Pokémon is shiny and its form
        String speciesName = pokemon.getSpecies().getName().toLowerCase();
        String formName = pokemon.getForm().getName().toLowerCase();
        String spritePath = "textures/sprites/";

        // Check if the Pokémon is shiny
        if (pokemon.getShiny()) {
            spritePath += "shiny/";
        } else {
            spritePath += "regular/";
        }

        // Append the form name if it exists (e.g., "meowth-alola")
        if (!formName.isEmpty() && !formName.equals("normal")) {
            speciesName += "-" + formName;
        }

        // Construct the sprite path
        this.pokemonSprite = class_2960.method_60655("cobblemonextradata", spritePath + speciesName + ".png");
        this.originMark = class_2960.method_60655("cobblemonextradata", "textures/origin/" + originMarkSprite + ".png");
    }

    @Override
    public void method_25394(class_332 guiGraphics, int mouseX, int mouseY, float partialTicks) {
        // Render the background with the correct arguments
        this.method_25420(guiGraphics, mouseX, mouseY, partialTicks);
        super.method_25394(guiGraphics, mouseX, mouseY, partialTicks);

        // Define the position and size of the background panel
        int panelWidth = 220;
        int panelHeight = 120;
        int x = (this.field_22789 - panelWidth) / 2;
        int y = (this.field_22790 - panelHeight) / 2;

        // Size of the Pokémon sprite
        int spriteWidth = 68;
        int spriteHeight = 56;

        // Compute the coordinates to center the sprite horizontally and position it properly
        int spriteX = (this.field_22789 - spriteWidth) / 2;
        int spriteY = y - spriteHeight;

        // Draw the Pokémon sprite
        drawTexture(guiGraphics, pokemonSprite, spriteX, spriteY, spriteWidth, spriteHeight);

        // Draw a semi-transparent background panel with a shadow
        guiGraphics.method_25294(x, y, x + panelWidth, y + panelHeight, 0x80000000);
        guiGraphics.method_25294(x + 2, y + 2, x + panelWidth + 2, y + panelHeight + 2, 0x20000000);

        // Draw a border around the panel
        guiGraphics.method_25294(x - 1, y - 1, x + panelWidth + 1, y, 0xFFAAAAAA);
        guiGraphics.method_25294(x - 1, y + panelHeight, x + panelWidth + 1, y + panelHeight + 1, 0xFFAAAAAA);
        guiGraphics.method_25294(x - 1, y, x, y + panelHeight, 0xFFAAAAAA);
        guiGraphics.method_25294(x + panelWidth, y, x + panelWidth + 1, y + panelHeight, 0xFFAAAAAA);

        // Draw the Pokémon data on the screen
        int textX = x + 10;
        int textY = y + 10;

        // Title: Pokémon Info (with shadow)
        guiGraphics.method_51433(this.field_22793, "Pokémon Info", textX, textY, 0xFFFFFF, true);

        // Origin Game (with shadow)
        String originGame = pokemon.getPersistentData().method_10545("OriginGame")
                ? pokemon.getPersistentData().method_10558("OriginGame").toLowerCase()
                : "cobblemon";
        String regionName = OriginGameMapper.getRegion(originGame);
        guiGraphics.method_51433(this.field_22793, "This Pokémon originated from " + regionName, textX, textY + 20, 0xFFFFFF, true);

        // Met Date (with shadow)
        String dateString = pokemon.getPersistentData().method_10545("MetDate")
                ? pokemon.getPersistentData().method_10558("MetDate")
                : "Unknown";
        guiGraphics.method_51433(this.field_22793, dateString, textX, textY + 40, 0xFFFFFF, true);

        // Met Location (with shadow)
        String metLocation = pokemon.getPersistentData().method_10558("MetLocation");
        if (!metLocation.contains(":")) {
            metLocation = "Cobblemon Transporter";
        } else {
            metLocation = metLocation.substring(metLocation.indexOf(":") + 1);
            metLocation = metLocation.replace("_", " ");
            metLocation = capitalizeEachWord(metLocation);
        }
        guiGraphics.method_51433(this.field_22793, metLocation, textX, textY + 60, 0xFFFFFF, true);

        // Met Level (with shadow)
        int metLevel = pokemon.getPersistentData().method_10545("MetLevel")
                ? pokemon.getPersistentData().method_10550("MetLevel")
                : pokemon.getLevel();
        guiGraphics.method_51433(this.field_22793, "Met at Lv. " + metLevel + ".", textX, textY + 80, 0xFFFFFF, true);

        // Draw the origin mark at the bottom right of the panel
        int originMarkSize = 16;
        int originMarkX = x + panelWidth - originMarkSize - 5;
        int originMarkY = y + panelHeight - originMarkSize - 5;

        drawTexture(guiGraphics, originMark, originMarkX, originMarkY, originMarkSize, originMarkSize);

        /* COMMENTED OUT: Marks/Ribbons display functionality
        // Fetch the list of marks from persistent data
        CompoundTag data = pokemon.getPersistentData();
        if (data.contains("Ribbons", 11)) {
            IntArrayTag ribbons = (IntArrayTag) data.get("Ribbons");
            assert ribbons != null;
            int[] ribbonIds = ribbons.getAsIntArray();

            // Ribbon settings
            int markSize = 16; // Size of each ribbon icon
            int markSpacing = 5; // Spacing between ribbon icons
            int maxRibbonsPerRow = 6; // Maximum number of ribbons per row
            int ribbonPanelPadding = 10; // Padding around the ribbon panel
            int ribbonPanelMargin = 20; // Additional margin between the main box and ribbon box

            // Calculate the number of rows needed
            int numRows = (int) Math.ceil((double) ribbonIds.length / maxRibbonsPerRow);

            // Calculate the total width and height of the ribbon panel
            int ribbonPanelWidth = Math.min(ribbonIds.length, maxRibbonsPerRow) * (markSize + markSpacing) - markSpacing;
            int ribbonPanelHeight = numRows * (markSize + markSpacing) - markSpacing;

            // Position the ribbon panel below the main box with additional margin
            int ribbonPanelX = x + (panelWidth - ribbonPanelWidth) / 2; // Center horizontally
            int ribbonPanelY = y + panelHeight + ribbonPanelMargin; // Position below the main box with margin

            // Draw a semi-transparent background for the ribbon panel
            guiGraphics.fill(
                    ribbonPanelX - ribbonPanelPadding,
                    ribbonPanelY - ribbonPanelPadding,
                    ribbonPanelX + ribbonPanelWidth + ribbonPanelPadding,
                    ribbonPanelY + ribbonPanelHeight + ribbonPanelPadding,
                    0x80000000
            );

            // Draw a border around the ribbon panel
            guiGraphics.fill(
                    ribbonPanelX - ribbonPanelPadding - 1,
                    ribbonPanelY - ribbonPanelPadding - 1,
                    ribbonPanelX + ribbonPanelWidth + ribbonPanelPadding + 1,
                    ribbonPanelY - ribbonPanelPadding,
                    0xFFAAAAAA
            );
            guiGraphics.fill(
                    ribbonPanelX - ribbonPanelPadding - 1,
                    ribbonPanelY + ribbonPanelHeight + ribbonPanelPadding,
                    ribbonPanelX + ribbonPanelWidth + ribbonPanelPadding + 1,
                    ribbonPanelY + ribbonPanelHeight + ribbonPanelPadding + 1,
                    0xFFAAAAAA
            );
            guiGraphics.fill(
                    ribbonPanelX - ribbonPanelPadding - 1,
                    ribbonPanelY - ribbonPanelPadding,
                    ribbonPanelX - ribbonPanelPadding,
                    ribbonPanelY + ribbonPanelHeight + ribbonPanelPadding,
                    0xFFAAAAAA
            );
            guiGraphics.fill(
                    ribbonPanelX + ribbonPanelWidth + ribbonPanelPadding,
                    ribbonPanelY - ribbonPanelPadding,
                    ribbonPanelX + ribbonPanelWidth + ribbonPanelPadding + 1,
                    ribbonPanelY + ribbonPanelHeight + ribbonPanelPadding,
                    0xFFAAAAAA
            );

            // Draw the ribbons
            int currentRow = 0;
            int currentCol = 0;
            for (int markId : ribbonIds) {
                ResourceLocation markTexture = MarkMapper.getMarkTexture(markId);

                if (markTexture != null) {
                    int ribbonX = ribbonPanelX + currentCol * (markSize + markSpacing);
                    int ribbonY = ribbonPanelY + currentRow * (markSize + markSpacing);

                    drawTexture(guiGraphics, markTexture, ribbonX, ribbonY, markSize, markSize);

                    // Add tooltip for the ribbon
                    if (mouseX >= ribbonX && mouseX < ribbonX + markSize && mouseY >= ribbonY && mouseY < ribbonY + markSize) {
                        String ribbonName = MarkMapper.getMarkName(markId);
                        guiGraphics.renderTooltip(this.font, Component.literal(ribbonName), mouseX, mouseY);
                    }

                    // Move to the next column
                    currentCol++;
                    if (currentCol >= maxRibbonsPerRow) {
                        currentCol = 0;
                        currentRow++;
                    }
                }
            }
        }
        */
    }

    // Helper method to capitalize each word
    private String capitalizeEachWord(String text) {
        String[] words = text.split(" ");
        StringBuilder capitalized = new StringBuilder();
        for (String word : words) {
            capitalized.append(Character.toUpperCase(word.charAt(0)))
                    .append(word.substring(1).toLowerCase())
                    .append(" ");
        }
        return capitalized.toString().trim();
    }

    private void drawTexture(class_332 guiGraphics, class_2960 texture, int x, int y, int width, int height) {
        RenderSystem.setShaderTexture(0, texture);
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
        RenderSystem.texParameter(GL11.GL_TEXTURE_2D, GL11.GL_TEXTURE_MIN_FILTER, GL11.GL_NEAREST);
        RenderSystem.texParameter(GL11.GL_TEXTURE_2D, GL11.GL_TEXTURE_MAG_FILTER, GL11.GL_NEAREST);
        guiGraphics.method_25290(texture, x, y, 0, 0, width, height, width, height);
    }

    @Override
    public boolean method_25422() {
        return true;
    }
}