package com.cobblemon.fabric.example;

import com.cobblemon.mod.common.api.Priority;
import com.cobblemon.mod.common.api.events.CobblemonEvents;
import com.cobblemon.mod.common.pokemon.Pokemon;
import net.fabricmc.api.ModInitializer;
import net.minecraft.class_1959;
import net.minecraft.class_2960;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_7924;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

public class EXTServer implements ModInitializer {
    public static final Logger LOGGER = LoggerFactory.getLogger("CobbleExtraData");

    @Override
    public void onInitialize() {
        // Subscribe to Cobblemon events for server-side handling
        CobblemonEvents.POKEMON_CAPTURED.subscribe(Priority.NORMAL, event -> {
            try {
                handlePokemonEvent(event.getPokemon(), event.getPlayer());
            } catch (Exception e) {
                logError("POKEMON_CAPTURED", e);
            }
            return null;
        });

        CobblemonEvents.STARTER_CHOSEN.subscribe(Priority.NORMAL, event -> {
            try {
                handlePokemonEvent(event.getPokemon(), event.getPlayer());
            } catch (Exception e) {
                logError("STARTER_CHOSEN", e);
            }
            return null;
        });

        LOGGER.info("Server-side initialization complete.");
    }

    private void handlePokemonEvent(Pokemon pokemon, class_3222 player) {
        try {
            // Server-level logic for Pokémon event handling
            class_3218 world = (class_3218) player.method_37908();
            LocalDate currentDate = LocalDate.now();
            String metDate = currentDate.format(DateTimeFormatter.ISO_LOCAL_DATE);
            pokemon.getPersistentData().method_10582("MetDate", metDate);

            class_1959 biome = world.method_23753(player.method_24515()).comp_349();
            class_2960 biomeId = world.method_30349().method_30530(class_7924.field_41236).method_10221(biome);
            String biomeName = biomeId.toString();
            pokemon.getPersistentData().method_10582("MetLocation", biomeName);

            int metLevel = pokemon.getLevel();
            pokemon.getPersistentData().method_10569("MetLevel", metLevel);

            pokemon.getPersistentData().method_10582("OriginGame", "Cobblemon");

            LOGGER.info("Pokémon event handled successfully:");
            LOGGER.info("Met Date: {}", metDate);
            LOGGER.info("Met Biome: {}", biomeName);
            LOGGER.info("Met Level: {}", metLevel);
        } catch (Exception e) {
            logError("PokemonEvent", e);
        }
    }

    private void logError(String eventName, Exception e) {
        // Generalized error logging for event handlers
        LOGGER.error("An error occurred in the {} event handler:", eventName, e);
    }
}